tags={
    "Translation"
}
name="Code Geass Black Requiem RU"
dependencies={
    "Code Geass: Black Requiem"
}
supported_version="1.19.*"
path="mod/Code Geass Black Requiem RU"
name="Code Geass: Black Requiem RUS | by DxrKhaptan"